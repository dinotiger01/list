
set(target "List")
set(working_dir "/home/FFlyingFish/Downloads/untitled1")
set(src_and_dest_list
    "/home/FFlyingFish/Downloads/untitled1/QML/main.qml"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/QML/main.qml"
    "/home/FFlyingFish/Downloads/untitled1/QML/pryQml.qml"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/QML/pryQml.qml"
    "/home/FFlyingFish/Downloads/untitled1/QML/taskQml.qml"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/QML/taskQml.qml"

)
set(timestamp_file "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/.qt/List_qml.txt")
