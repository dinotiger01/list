
set(target "List")
set(working_dir "/home/FFlyingFish/Downloads/untitled1")
set(src_and_dest_list
    "/home/FFlyingFish/Downloads/untitled1/SVG/check.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/check.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/edit.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/edit.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/garbage.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/garbage.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/home.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/home.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/minus.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/minus.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/plus.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/plus.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/restart.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/restart.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/search.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/search.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/settings.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/settings.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/sync.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/sync.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/up-arrow.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/up-arrow.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/up-arrow2.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/up-arrow2.svg"
    "/home/FFlyingFish/Downloads/untitled1/SVG/X.svg"
    "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/EngineMod/SVG/X.svg"

)
set(timestamp_file "/home/FFlyingFish/Downloads/untitled1/cmake-build-release/.qt/List_res.txt")
