set(__QT_DEPLOY_TARGET_List_FILE /home/FFlyingFish/Downloads/untitled1/cmake-build-release/List)
set(__QT_DEPLOY_TARGET_List_TYPE EXECUTABLE)
