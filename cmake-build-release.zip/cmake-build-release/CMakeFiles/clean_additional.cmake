# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Release")
  file(REMOVE_RECURSE
  "CMakeFiles/List_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/List_autogen.dir/ParseCache.txt"
  "List_autogen"
  )
endif()
