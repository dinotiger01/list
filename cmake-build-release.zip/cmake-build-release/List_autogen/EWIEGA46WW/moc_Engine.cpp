/****************************************************************************
** Meta object code from reading C++ file 'Engine.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.11.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Engine.h"
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Engine.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.11.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN6Engine9EngineModE_t {};
} // unnamed namespace

template <> constexpr inline auto Engine::EngineMod::qt_create_metaobjectdata<qt_meta_tag_ZN6Engine9EngineModE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "Engine::EngineMod",
        "QML.Element",
        "auto",
        "setPar",
        "",
        "par",
        "crate",
        "tot",
        "testing",
        "setBulkCreate",
        "obj",
        "type",
        "refrechAll",
        "creatTask",
        "name",
        "pry",
        "rep",
        "delay",
        "due",
        "notes",
        "people",
        "edit",
        "createType",
        "dex",
        "old",
        "createPerson",
        "php",
        "reqHr",
        "updateFilter",
        "peps",
        "types",
        "dates",
        "getPersonName",
        "i",
        "getPersonSize",
        "getPersonDex",
        "getPersonPhp",
        "getTypeName",
        "getTypeSize",
        "getTypeDex",
        "getPryName",
        "getPrySize",
        "getCurrentDate",
        "deletePerson",
        "deleteType",
        "deleter",
        "taskToDelete",
        "editOpen",
        "editClose",
        "permDel",
        "setFilter",
        "QVariantList",
        "pep",
        "initFilter",
        "typ",
        "pe",
        "sqlPullFilt"
    };

    QtMocHelpers::UintData qt_methods {
        // Method 'setPar'
        QtMocHelpers::MethodData<void(QObject *, QObject *, QObject *)>(3, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QObjectStar, 5 }, { QMetaType::QObjectStar, 6 }, { QMetaType::QObjectStar, 7 },
        }}),
        // Method 'testing'
        QtMocHelpers::MethodData<void()>(8, 4, QMC::AccessPublic, QMetaType::Void),
        // Method 'setBulkCreate'
        QtMocHelpers::MethodData<void(QObject *, QString)>(9, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QObjectStar, 10 }, { QMetaType::QString, 11 },
        }}),
        // Method 'refrechAll'
        QtMocHelpers::MethodData<void()>(12, 4, QMC::AccessPublic, QMetaType::Void),
        // Method 'creatTask'
        QtMocHelpers::MethodData<void(QString, int, int, int, QString, QString, QString, QString, bool)>(13, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 }, { QMetaType::Int, 15 }, { QMetaType::Int, 16 }, { QMetaType::Int, 17 },
            { QMetaType::QString, 18 }, { QMetaType::QString, 19 }, { QMetaType::QString, 20 }, { QMetaType::QString, 11 },
            { QMetaType::Bool, 21 },
        }}),
        // Method 'createType'
        QtMocHelpers::MethodData<void(QString, int, QString)>(22, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 }, { QMetaType::Int, 23 }, { QMetaType::QString, 24 },
        }}),
        // Method 'createPerson'
        QtMocHelpers::MethodData<void(int, QString, QString, QString)>(25, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 23 }, { QMetaType::QString, 14 }, { QMetaType::QString, 26 }, { QMetaType::QString, 27 },
        }}),
        // Method 'updateFilter'
        QtMocHelpers::MethodData<void(QString, QString, QString, QString)>(28, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 }, { QMetaType::QString, 29 }, { QMetaType::QString, 30 }, { QMetaType::QString, 31 },
        }}),
        // Method 'getPersonName'
        QtMocHelpers::MethodData<QString(int, QObject *)>(32, 4, QMC::AccessPublic, QMetaType::QString, {{
            { QMetaType::Int, 33 }, { QMetaType::QObjectStar, 10 },
        }}),
        // Method 'getPersonSize'
        QtMocHelpers::MethodData<int()>(34, 4, QMC::AccessPublic, QMetaType::Int),
        // Method 'getPersonDex'
        QtMocHelpers::MethodData<int(int)>(35, 4, QMC::AccessPublic, QMetaType::Int, {{
            { QMetaType::Int, 33 },
        }}),
        // Method 'getPersonPhp'
        QtMocHelpers::MethodData<QString(int)>(36, 4, QMC::AccessPublic, QMetaType::QString, {{
            { QMetaType::Int, 33 },
        }}),
        // Method 'getTypeName'
        QtMocHelpers::MethodData<QString(int, QObject *)>(37, 4, QMC::AccessPublic, QMetaType::QString, {{
            { QMetaType::Int, 33 }, { QMetaType::QObjectStar, 10 },
        }}),
        // Method 'getTypeSize'
        QtMocHelpers::MethodData<int()>(38, 4, QMC::AccessPublic, QMetaType::Int),
        // Method 'getTypeDex'
        QtMocHelpers::MethodData<int(int)>(39, 4, QMC::AccessPublic, QMetaType::Int, {{
            { QMetaType::Int, 33 },
        }}),
        // Method 'getPryName'
        QtMocHelpers::MethodData<QString(int, QObject *)>(40, 4, QMC::AccessPublic, QMetaType::QString, {{
            { QMetaType::Int, 33 }, { QMetaType::QObjectStar, 10 },
        }}),
        // Method 'getPrySize'
        QtMocHelpers::MethodData<int()>(41, 4, QMC::AccessPublic, QMetaType::Int),
        // Method 'getCurrentDate'
        QtMocHelpers::MethodData<QString()>(42, 4, QMC::AccessPublic, QMetaType::QString),
        // Method 'deletePerson'
        QtMocHelpers::MethodData<void(int)>(43, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 23 },
        }}),
        // Method 'deleteType'
        QtMocHelpers::MethodData<void(int)>(44, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 23 },
        }}),
        // Method 'deleter'
        QtMocHelpers::MethodData<void(QObject *, int)>(45, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QObjectStar, 46 }, { QMetaType::Int, 23 },
        }}),
        // Method 'editOpen'
        QtMocHelpers::MethodData<void(int)>(47, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 23 },
        }}),
        // Method 'editClose'
        QtMocHelpers::MethodData<void()>(48, 4, QMC::AccessPublic, QMetaType::Void),
        // Method 'permDel'
        QtMocHelpers::MethodData<void()>(49, 4, QMC::AccessPublic, QMetaType::Void),
        // Method 'setFilter'
        QtMocHelpers::MethodData<void(QString, QVariantList, QStringList, QStringList)>(50, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 }, { 0x80000000 | 51, 52 }, { QMetaType::QStringList, 11 }, { QMetaType::QStringList, 31 },
        }}),
        // Method 'initFilter'
        QtMocHelpers::MethodData<void(QObject *, QObject *)>(53, 4, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QObjectStar, 54 }, { QMetaType::QObjectStar, 55 },
        }}),
        // Method 'sqlPullFilt'
        QtMocHelpers::MethodData<void()>(56, 4, QMC::AccessPublic, QMetaType::Void),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    QtMocHelpers::UintData qt_constructors {};
    QtMocHelpers::ClassInfos qt_classinfo({
            {    1,    2 },
    });
    return QtMocHelpers::metaObjectData<EngineMod, void>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums, qt_constructors, qt_classinfo);
}
Q_CONSTINIT const QMetaObject Engine::EngineMod::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6Engine9EngineModE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6Engine9EngineModE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN6Engine9EngineModE_t>.metaTypes,
    nullptr
} };

void Engine::EngineMod::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<EngineMod *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->setPar((*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[3]))); break;
        case 1: _t->testing(); break;
        case 2: _t->setBulkCreate((*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->refrechAll(); break;
        case 4: _t->creatTask((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[4])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[6])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[7])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[8])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[9]))); break;
        case 5: _t->createType((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 6: _t->createPerson((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[4]))); break;
        case 7: _t->updateFilter((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[4]))); break;
        case 8: { QString _r = _t->getPersonName((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[2])));
            if (_a[0]) *reinterpret_cast<QString*>(_a[0]) = std::move(_r); }  break;
        case 9: { int _r = _t->getPersonSize();
            if (_a[0]) *reinterpret_cast<int*>(_a[0]) = std::move(_r); }  break;
        case 10: { int _r = _t->getPersonDex((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast<int*>(_a[0]) = std::move(_r); }  break;
        case 11: { QString _r = _t->getPersonPhp((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast<QString*>(_a[0]) = std::move(_r); }  break;
        case 12: { QString _r = _t->getTypeName((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[2])));
            if (_a[0]) *reinterpret_cast<QString*>(_a[0]) = std::move(_r); }  break;
        case 13: { int _r = _t->getTypeSize();
            if (_a[0]) *reinterpret_cast<int*>(_a[0]) = std::move(_r); }  break;
        case 14: { int _r = _t->getTypeDex((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast<int*>(_a[0]) = std::move(_r); }  break;
        case 15: { QString _r = _t->getPryName((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[2])));
            if (_a[0]) *reinterpret_cast<QString*>(_a[0]) = std::move(_r); }  break;
        case 16: { int _r = _t->getPrySize();
            if (_a[0]) *reinterpret_cast<int*>(_a[0]) = std::move(_r); }  break;
        case 17: { QString _r = _t->getCurrentDate();
            if (_a[0]) *reinterpret_cast<QString*>(_a[0]) = std::move(_r); }  break;
        case 18: _t->deletePerson((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->deleteType((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 20: _t->deleter((*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2]))); break;
        case 21: _t->editOpen((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 22: _t->editClose(); break;
        case 23: _t->permDel(); break;
        case 24: _t->setFilter((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QVariantList>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QStringList>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<QStringList>>(_a[4]))); break;
        case 25: _t->initFilter((*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QObject*>>(_a[2]))); break;
        case 26: _t->sqlPullFilt(); break;
        default: ;
        }
    }
}

const QMetaObject *Engine::EngineMod::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Engine::EngineMod::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN6Engine9EngineModE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Engine::EngineMod::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 27;
    }
    return _id;
}
QT_WARNING_POP
